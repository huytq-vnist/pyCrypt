def getCrypt():
{
    print('123')
}